#include <stdio.h>
#include <stdlib.h>
#include <time.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int i,j,a[2][2],x,z,y;
	for(i=0;i<3;i++){
		for(j=0;j<3;j++){
			a[i][j]=(rand()%50)+1;
			
		}
	}
	for(i=0;i<3;i++){
		for(j=0;j<3;j++){
			printf("%d   ",a[i][j]);
		}
		printf("\n");
	}
	x=a[0][0]+a[0][1]+a[0][2];
	z=a[1][0]+a[1][1]+a[1][2];
	y=a[2][0]+a[2][1]+a[2][2];
			printf("�Ĥ@�C:%d ����:%d \t",x,x/3);
			printf("�ĤG�C:%d ����:%d \t",z,z/3);
			printf("�ĤT�C:%d ����:%d \t",y,y/3);
			printf("�﨤�u:%d,%d",a[0][0]+a[1][1]+a[2][2],a[2][0]+a[1][1]+a[0][2]);
		
	
	return 0;
}
