#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int a,n,i,j;
	printf("�п�J�@�ӼơG");
	scanf("%d",&a);
	if((1<=a)&&(a<=50)){
		for(i=0;i<=a;i++){
		for(j=1;j<=i;j++){
		   printf(" ");
		}
		for(n=0;n<a-i;n++){
		   printf("*");
		}
		printf("\n");
	}
}
	return 0;
}
