#include <stdio.h>
#include <stdlib.h>
#define MAX 80
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int time=0,change;
struct node{
	int id;
	int data;
	struct node *next;
};
struct node *first,*now,*front;
int main(int argc, char *argv[]) {
	FILE *fptr,*fptr2;
	char str[MAX];
	int i=1,j;
	
	fptr=fopen("c://test.txt","r"); /*�Ч����ɥ��C�Ѵ��աA�o�˴N���Χ�{���o�̪���m�A�p�G�i�o���ժ������ɮפW�h�N�n�A�O�o�R���o�q��!!*/
	while(!feof(fptr)){
		fgets(str,MAX,fptr);
		now=(struct node *) malloc(sizeof(struct node));
		now->id=i;
		now->data=atoi(str);
		if(i==1){
			first=now;
		}
		else{
			front->next=now;
		}
		now->next=NULL;
		front=now;
		i++;
		time++;
	}
	now=first;
	while(now!=NULL){
		printf("%d,",now->id);
		printf("%d\n",now->data);
	
		now=now->next;
	}
	printf("--�Ƨǫ�--\n");
	b_sort();
	fptr2=fopen("C://out.txt","w"); 
	now=first;
	char a[MAX],b[MAX];
	while(now!=NULL){
		printf("%d,",now->id);
		printf("%d\n",now->data);
		sprintf(a,"%d",now->id);
		sprintf(b,"%d",now->data);
		fputs(a,fptr2);
		fputs(",",fptr2);
		fputs(b,fptr2);
		putc('\n',fptr2);
		now=now->next;
	}
	fclose(fptr);
	fclose(fptr2);
	return 0;
}
int b_sort(){
	int i;
		for(i=0;i<time;i++){
		now=first;
		while(now->next!=NULL){
			if(now->next->data>now->data){
				change=0;
				change=now->next->data;
				now->next->data=now->data;
				now->data=change;
				change=0;
				change=now->next->id;
				now->next->id=now->id;
				now->id=change;
			}
			now=now->next;
		}
	}
}
