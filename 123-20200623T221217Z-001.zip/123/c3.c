#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define n 5
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int show(int data[]);
int sort(int data1[]);
int main(int argc, char *argv[]) {
	int data[n],i;
	srand(time(NULL));
	for(i=0;i<n;i++){
		data[i]=(rand()%1000)+1;
	}
	show(data);
	printf("\n�Ƨǵ��G:\n");
	sort(data);
	return 0;
}
int show(int data[]){
	int i;
	for(i=0;i<n;i++)
		printf("%d ",data[i]);
}
int sort(int data1[]){
	int i,j,t;
	for(i=1;i<n;i++){
		for(j=0;j<n-i;j++){
			if(data1[j]<data1[j+1]){
				t=data1[j];
				data1[j]=data1[j+1];
				data1[j+1]=t;
			}
		}
	}
	for(j=0;j<n;j++)
		printf("%d ",data1[j]);
}
