#include <stdio.h>
#include <stdlib.h>
#include <time.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
	struct data{
			int id;
			int en;
			int ch;
			float a;
	}st[50],x;


int main(int argc, char *argv[]) {
	
	
	int i;
	srand(time(NULL));
	for(i=0;i<50;i++){
		st[i].id=i+1;
		st[i].en=(rand()%100)+1;
		st[i].ch=(rand()%100)+1;
		st[i].a=(st[i].en+st[i].ch)/2.0;
		printf("�Ǹ�:%d\n�^��:%d\n���:%d\n����:%.1f\n\n",st[i].id,st[i].en,st[i].ch,st[i].a);
	}
	bbs(st);
	printf("--�e�Q�W--\n\n");
	show();
	return 0;
}
int bbs(struct data st[]){
	int i,j;
	for(i=1;i<50;i++){
		for(j=0;j<(50-i);j++){
			if(st[j].a<st[j+1].a){
				x=st[j];
				st[j]=st[j+1];
				st[j+1]=x;
			}
		}
	}
}
int show(){
	int i;
	for(i=0;i<10;i++){
		printf("��%d�W �Ǹ�:%d\n�^��:%d\n���:%d\n����:%.1f\n\n",i+1,i+1,st[i].en,st[i].ch,st[i].a);
	}
}




