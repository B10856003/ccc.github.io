#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float x,y;
	printf("�п�JX,Y��:");
	scanf("%f %f",&x,&y);
	if(x>0){
		if(y>0){
			printf("(%.1f,%.1f)�b�Ĥ@�H��",x,y);
		}
		if(y<0){
			printf("(%.1f,%.1f)�b�ĥ|�H��",x,y);
		}
	}
	else if(x<0){
		if(y>0){
			printf("(%.1f,%.1f)�b�ĤG�H��",x,y);
		}
		if(y<0){
			printf("(%.1f,%.1f)�b�ĤT�H��",x,y);
		}
	}
	return 0;
}
