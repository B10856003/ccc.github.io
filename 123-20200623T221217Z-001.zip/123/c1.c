#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int n;
	printf("�п�J���n:");
	scanf("%d",&n);
	printf("f(%d)=%d",n,num(n)) ;
	return 0;
}
int num(int n){
	if(n==0)
		return 3;
	else 
		return 2*num(n-1)-5;
}
